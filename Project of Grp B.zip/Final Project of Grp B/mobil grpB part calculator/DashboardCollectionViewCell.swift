//
//  DashboardCollectionViewCell.swift
//  mobil grpB part calculator
//
//  Created by Sium on 7/22/17.
//  Copyright © 2017 Mobioapp. All rights reserved.
//

import UIKit

class DashboardCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var dashBoardLabelOutlet: UILabel!
    @IBOutlet weak var dashBoardImageOutlet: UIImageView!
}
