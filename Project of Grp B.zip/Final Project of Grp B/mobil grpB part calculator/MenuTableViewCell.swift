//
//  MenuTableViewCell.swift
//  mobil grpB part calculator
//
//  Created by Mobioapp on 7/25/17.
//  Copyright © 2017 Mobioapp. All rights reserved.
//

import UIKit

class MenuTableViewCell: UITableViewCell {

    @IBOutlet weak var menuLabelOutlet: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
